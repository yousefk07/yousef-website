import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.*;
public class CPTMain implements WindowListener{
        private JFrame frame;
        private JPanel panel, panelLabels;
        private JLabel lblPaymentOptions, lblLogo, lblSubtotal, lblDeliveryFee, lblHST, lblGrandTotal, lblThreeToppings, lblDiscount;
        private Font f;
        public static void main(String[] args) {
                new CPTMain();  
        }       
        
        public CPTMain() {
                //Frame and Panel declarations/configurations, and bringing in the other class
                frame = new JFrame("Little Caesar's");
                panel = new JPanel();
                panelLabels = new JPanel();
                panelLabels.setBackground(Color.white);
                panelLabels.setBounds(105,390,200,190);
                panel.setLayout(null);
                panel.setBackground(Color.white);
                CPTButtons cb = new CPTButtons();
                cb.addComponents(panel);
                
                //LABELS
                lblSubtotal = createLabel("SUBTOTAL:"); //Creating a label with the specified text
                lblDeliveryFee = createLabel("DELIVERY FEE:");  //Creating a label with the specified text
                lblHST = createLabel("HST:");  //Creating a label with the specified text
                lblGrandTotal = createLabel("GRAND TOTAL:");  //Creating a label with the specified text
                //Three Toppings
                lblThreeToppings = createLabel("First three (3) toppings are free!");  //Creating a label with the specified text
                f = new Font("Arial",Font.PLAIN,10); //Font for the small text
                lblThreeToppings.setFont(f);
                lblThreeToppings.setBounds(175,228,200,100);
                //Image Labels for the Logo and the Payment Options
                lblPaymentOptions = new JLabel();
                lblPaymentOptions.setIcon(new ImageIcon("PaymentOptions.png"));
                lblPaymentOptions.setBounds(20,395,80,166);
                lblLogo = new JLabel();
                lblLogo.setIcon(new ImageIcon("LittleCaesarsLogo.png"));
                lblLogo.setBounds(33,20,516,97);
                
                //Adding all the Labels for the Subtotal, etc, to one panel so that I can use grid layout instead of coordinates
                panelLabels.add(lblSubtotal);
                panelLabels.add(lblDeliveryFee);
                panelLabels.add(lblHST);
                panelLabels.add(lblGrandTotal);
                panelLabels.setLayout(new GridLayout(4,1));
                
                //Discount Code Label
                lblDiscount = createLabel("Enter Disc Code:");
                lblDiscount.setHorizontalAlignment(JLabel.LEFT);
                lblDiscount.setBounds(30,560,230,25);
                lblDiscount.setFont(f);
                
                //Adding all the other things, including the panel for labels and the other labels
                panel.add(panelLabels);
                panel.add(lblThreeToppings);
                panel.add(lblPaymentOptions);
                panel.add(lblLogo);
                panel.add(lblDiscount);
                //Frame configuration
                frame.setContentPane(panel);
                frame.addWindowListener(this);
                frame.setBounds(500,150,600,650);
                frame.setResizable(false);
                frame.setVisible(true);
        }
        //Method to create labels
        public JLabel createLabel(String message) {
                JLabel lbl = new JLabel();
                lbl.setText(message); //to set the text given from the parameter
                lbl.setBackground(Color.white); //all text must have white background
                lbl.setHorizontalAlignment(JLabel.CENTER);
                return lbl;
        }
        
        public void windowOpened(WindowEvent e) {               
        }
        public void windowClosing(WindowEvent e) {      //Extra feature: gives options if the X button is clicked
                int option;
                option = JOptionPane.showConfirmDialog(frame, "Are you sure you want to exit?","Little Caesar's",JOptionPane.YES_NO_OPTION);
                if(option==0) { //if user clicks yes, it closes but gives a message first
                        JOptionPane.showMessageDialog(frame, "Thank you for choosing Little Caesars!","Little Caesar's",JOptionPane.INFORMATION_MESSAGE);
                        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                }
                else { //if user clicks no, it returns to main screen
                        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                }
        }
        public void windowClosed(WindowEvent e) {               
        }
        public void windowIconified(WindowEvent e) {            
        }
        public void windowDeiconified(WindowEvent e) {          
        }
        public void windowActivated(WindowEvent e) {            
        }
        public void windowDeactivated(WindowEvent e) {          
        }
}
