import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import java.util.Locale;
public class CPTOptions implements ActionListener{
        //VARIABLE DECLARATIPON
        protected JRadioButton[] rbSizes;
        protected JPanel panel2, panel3, panel4, panel5, panel6;
        protected JComboBox<Integer>[] cbBeverages; //Array for the combo boxes
        protected JCheckBox[] chkToppings; //array for the check boxes
        protected JLabel[] lblImageToppings, lblImageBeverages, lblDrinks;
        protected JLabel lblSizeCost, lblToppingsCost, lblBeveragesCost, lblPizzaSize;
        protected int counter; //needs to be here, rather than in the method, so that it updates correctly
        protected double costToppings, costBeverages, costSize; //needs to be accessed in other method
        protected NumberFormat nf; //accessed in other method
        protected ButtonGroup size; //needs to be accessed in the other method
        protected JTextField txtDiscount;

        //The @SuppressWarnings stops there from being an error with the combo boxes, it gave this as a solution when i clicked on the error
        @SuppressWarnings("unchecked")
        public CPTOptions() {
                //Number Formatting
                nf = NumberFormat.getCurrencyInstance(Locale.CANADA); //number format to canadian currency

                //STRING ARRAYS
                String[] toppingNames = {"Mushrooms","Pepperoni","Green Peppers","Bacon","Onions","Tomatoes","Hot Peppers","Extra Cheese"};
                String[] sizeNames = {"Small","Medium","Large","Party"};
                String[] drinkNames = {"Coke","Sprite","Orange","Root Beer"};

                //INITIALIZATION
                counter = 0; //initializing counter which will be used in a later method
                costToppings = 0; //initializing costToppings which will be used in a later method
                costBeverages = 0; //initializing costBeverages which will be used in a later method

                //IMAGE LABELS
                ImageIcon[] toppingImages = {new ImageIcon("mushrooms.jpg"),new ImageIcon("pepperoni.jpg"),new ImageIcon("greenpeppers.jpg"),new ImageIcon("bacon.jpg"),new ImageIcon("onions.jpg"),new ImageIcon("tomatoes.jpg"),new ImageIcon("hotpeppers.jpg"),new ImageIcon("extracheese.jpg")};
                ImageIcon[] beveragesImages = {new ImageIcon("coke.jpg"),new ImageIcon("sprite.png"),new ImageIcon("orange.jpg"),new ImageIcon("rootbeer.png")};

                //RADIO BUTTONS
                rbSizes = new JRadioButton[4];
                panel2 = createPanel(5,140,115,130,"SIZE"); //creating panel with the method
                size = new ButtonGroup(); //creating a group for the radio buttons
                for(int h = 0; h < rbSizes.length; h++) {
                        rbSizes[h] = createRadioButton(sizeNames[h]); //creating radioButton
                        size.add(rbSizes[h]); //adding to button group
                        panel2.add(rbSizes[h]); //adding to panel 2
                }

                //CHECK BOXES
                chkToppings = new JCheckBox[8]; //creating an array with 8 checkboxes for the toppings
                panel3 = createPanel(130,140,280,130,"TOPPINGS"); //panel for checkboxes
                panel3.setLayout(new GridLayout(4,2)); //for 4 rows, 2 columns
                for(int i = 0; i < chkToppings.length; i++) { //array to create the checkboxes and add to panel3
                        chkToppings[i] = createCheckBox(toppingNames[i]);
                        panel3.add(chkToppings[i]);
                }       

                //COMBO BOXES
                lblDrinks = new JLabel[4]; //Labels for the drink names
                panel4 = createPanel(415,140,175,130,"BEVERAGES"); //panel for combo boxes
                cbBeverages = new JComboBox[4]; //combo boxes for the drinks
                for(int p = 0; p < cbBeverages.length;p++) { //loop to create labels and combo boxes and add to panel
                        cbBeverages[p] = createComboBox();
                        lblDrinks[p] = createLabel(0,0,0,0,drinkNames[p]);
                        lblDrinks[p].setBorder(null);
                        panel4.add(lblDrinks[p]);
                        panel4.add(cbBeverages[p]);
                }
                panel4.setLayout(new GridLayout(4,2)); //to arrange the labels and combo boxes together in a 4:2 column/row arrangement

                /* LABELS SECTION */

                //Labels for costs for size, toppings, beverages
                lblSizeCost = createLabel(10,360,105,25,"$0.00"); //label specifically for updating size cost
                lblToppingsCost = createLabel(220,360,105,25,"$0.00"); //label specifically for updating toppings cost
                lblBeveragesCost = createLabel(450,355,105,25,"$0.00"); //label specifically for updating beverages cost

                //PIZZA SIZE IMAGE
                lblPizzaSize = createLabel(30,290,60,60,null); //Label for image depending on size of pizza
                lblPizzaSize.setBorder(null); //no border needed

                //TOPPINGS IMAGE
                lblImageToppings = new JLabel[8]; //labels for the 8 images cooresponding to the 8 toppings
                panel5 = createPanel(130,300,280,30,null); //panel for the images of the toppings
                panel5.setBorder(null);
                //Initializing and adding the 8 topping images to the panel 5
                for(int i = 0; i < lblImageToppings.length; i++) {
                        lblImageToppings[i] = new JLabel();
                        lblImageToppings[i].setIcon(toppingImages[i]);
                        panel5.add(lblImageToppings[i]);
                        lblImageToppings[i].setVisible(false); //originally false, will change to true if action performed
                }
                panel5.setLayout(new GridLayout(1,8)); //one by 8 arrangement of images

                //BEVERAGES IMAGES
                lblImageBeverages = new JLabel[4];
                panel6 = createPanel(425,300,140,30,null);
                panel6.setBorder(null);
                //Initializing and adding the label for the beverage images to panel 6
                for(int j = 0; j < lblImageBeverages.length; j++) {
                        lblImageBeverages[j] = new JLabel();
                        lblImageBeverages[j].setIcon(beveragesImages[j]);
                        panel6.add(lblImageBeverages[j]);
                        lblImageBeverages[j].setVisible(false); //originally false, will change to true if action performed
                }
                panel6.setLayout(new GridLayout(1,4));

                //TEXT FIELD (extra feature)
                //text field for discounts
                /* DISCOUNT CODES
                        ICS4U1: 20% OFF THE GRAND TOTAL
                        BIGSALE: 50% OFF THE GRAND TOTAL
                 */
                txtDiscount = new JTextField();
                txtDiscount.setBounds(20,580,100,25);
                txtDiscount.setHorizontalAlignment(JTextField.CENTER);
        }

        //METHOD FOR CREATING LABELS, takes in original x and y coordinate plus x dimension and y dimension, and a message
        //The first 4 parameters are required as this method is used for any label in this class, they arent neccasarily in line
        public JLabel createLabel(int xOg, int yOg, int xDim, int yDim, String message) {
                JLabel lbl = new JLabel();
                lbl.setBounds(xOg,yOg,xDim,yDim); //setting bounds
                lbl.setText(message); //assigning message
                lbl.setBorder(BorderFactory.createLineBorder(Color.gray)); //creating border
                lbl.setBackground(Color.white); //Background colour must be white
                lbl.setHorizontalAlignment(JLabel.CENTER);
                return lbl;
        }

        //METHOD FOR CREATING PANELS, takes in original x and y coordinates plus x dimension and y dimension and a message
        //The first 4 parameters are required as this method is used for any panel in this class, they arent neccasarily in line
        public JPanel createPanel(int xOg, int yOg, int xDim, int yDim, String message) {
                JPanel p = new JPanel();
                p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS)); //Setting layout for the panel
                p.setBounds(xOg, yOg, xDim, yDim); //setting bounds
                p.setBackground(Color.white); //Background must be white
                p.setBorder(BorderFactory.createTitledBorder(message)); //Creating titled border
                return p;
        }

        //METHOD FOR CREATING COMBO BOXES, does not take in any parameters as there is no variance in the combo boxes, theyre all the same
        public JComboBox<Integer> createComboBox() {
                Integer[] amountDrink = {0,1,2,3,4,5,6}; //the options for the combo box
                JComboBox<Integer> cb = new JComboBox<Integer>(amountDrink); //creating combo box with the 7 numbers as options
                cb.addActionListener(this);
                return cb;
        }

        //METHOD FOR CREATING CHECK BOX, takes in only a message for the checkbox
        public JCheckBox createCheckBox(String message) {
                JCheckBox chk = new JCheckBox(message);
                chk.addActionListener(this);
                chk.setBackground(Color.white);
                return chk;
        }

        //METHOD FOR CREATING RADIO BUTON, takes in only a message for the rb
        public JRadioButton createRadioButton(String message) {
                JRadioButton rb = new JRadioButton(message);
                rb.addActionListener(this);
                rb.setBackground(Color.white);
                return rb;
        }

        //Method to add all the panels and the leftover indiviual labels to the main panel in the main class
        public void addComponents(JPanel p) {
                p.add(panel2);
                p.add(panel3);
                p.add(panel4);
                p.add(lblSizeCost);
                p.add(lblToppingsCost);
                p.add(lblBeveragesCost);
                p.add(lblPizzaSize);
                p.add(panel5);
                p.add(panel6);
                p.add(txtDiscount);
        }

        //METHOD TO CONTROL ALL ACTIONS PERFORMED
        public void actionPerformed(ActionEvent e) {
                if (e.getSource() instanceof JRadioButton) { //IF IT IS A RADIO BUTTON CLICKED
                        double[] sizeCosts = {7.99,8.99,9.99,10.99}; //array to assign cost based on index of button
                        //array to assign image based on index of button
                        ImageIcon[] imgs = {new ImageIcon("small.jpg"),new ImageIcon("medium.png"),new ImageIcon("large.jpg"),new ImageIcon("party.jpg")};
                        //for loop to match the source to the button, and then assign the cooresponding price and image
                        for(int i = 0; i < rbSizes.length; i++) {
                                if(e.getSource()==rbSizes[i]) {
                                        costSize = sizeCosts[i];
                                        lblPizzaSize.setIcon(imgs[i]);
                                }
                        }
                        lblSizeCost.setText(nf.format(costSize)); //adding the cost to the label for size cost, plus formatting the cost
                }
                else if(e.getSource() instanceof JComboBox) { //IF IT IS A COMBO BOX CLICKED
                        int total = 0; //the initial total is 0
                        for(int i = 0; i < cbBeverages.length; i++) { //to go through the combo box array
                                if(e.getSource()==cbBeverages[i]) { //if the source is that specific combo box
                                        if(cbBeverages[i].getSelectedIndex()!=0) { //and if the index is not 0 (i.e, there was an amount of drinks selected)
                                                lblImageBeverages[i].setVisible(true); //then enable the cooresponding image
                                        }
                                        else {
                                                lblImageBeverages[i].setVisible(false); //else, do not enable that emage
                                        }
                                }
                        }       
                        //the total is the total amount of drinks, which we get through casting int to all the selections of the combo boxes and getting the sum
                        for(int j = 0; j < cbBeverages.length; j++) {
                                total += cbBeverages[j].getSelectedIndex();
                        }
                        //the total cost of beverages is simply the total amount of drinks multiplied by 0.99
                        costBeverages = total * 0.99;
                        costBeverages = Math.round(costBeverages*100)/100.0; //rounding
                        lblBeveragesCost.setText(nf.format(costBeverages)); //adding the cost to the label for beverage cost, plus formatting the cost
                }
                else { //IF IT IS A CHECKBOX
                        //if the source (that i casted to checkbox) is SELECTED, meaning that if the user interacts with a checkbox and it was a selection, not a deselection, then
                        if(((JCheckBox) e.getSource()).isSelected()) {
                                counter++; //the counter of the total amount of checkboxes selected is increased by one
                        }
                        else { //if a checkbox was interacted with and deselected
                                counter--; //the counter of the total amount of checkboxes is decreased by one
                        }

                        if(counter <= 3) { //If there are 3 or less toppings selected, the price is 0
                                costToppings = 0;
                        }
                        else { //however, if there are 4 or more toppings, the price is the amount of toppings subtracted by the three free ones, as each topping = $1
                                costToppings = counter-3;
                        }
                        //For loop for setting the images to visible depending on which topping was selected            
                        for(int i = 0; i < chkToppings.length;i++) {
                                if(e.getSource()==chkToppings[i]) { //if the source object is the same as the current index of the array
                                        if(chkToppings[i].isSelected()) { //AND if that source was selected
                                                lblImageToppings[i].setVisible(true); //that means we must make the image visible
                                        }
                                        else {
                                                lblImageToppings[i].setVisible(false); //otherwise, it was deselected and it must be made invisible
                                        }
                                }
                        }
                        lblToppingsCost.setText(nf.format(costToppings)); //adding the cost to the label for toppings cost, plus formatting the cost
                }

        }
}
