import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class CPTButtons extends CPTOptions implements ActionListener{
        private JButton btnCalculate, btnClear, btnCheckout, btnExit;
        private JLabel lblSubtotal, lblDelivery, lblHST, lblGrandTotal;
        private double grandTotal; //putting it here so it can be used in the checkout section aswell
        
        public CPTButtons() {
                super(); //to call the constructor in the CPTOptions class
                grandTotal = 0;
                btnCalculate = createButton(400,"CALCULATE"); //creating a button at specified y value with specified text
                btnClear = createButton(450,"CLEAR"); //creating a button at specified y value with specified text
                btnCheckout = createButton(500,"CHECKOUT"); //creating a button at specified y value with specified text
                btnExit = createButton(550,"EXIT"); //creating a button at specified y value with specified text
                lblSubtotal = createLabel(270, 405, 105, 25,"$0.00"); //creating a label for the subtotal
                lblDelivery = createLabel(270, 450, 105, 25,"$0.00"); //creating a label for the delivery fee
                lblDelivery.setOpaque(true); //must be opaque so that the background is green if necessary
                lblHST = createLabel(270, 495, 105, 25,"$0.00"); //creating a label for the HST
                lblGrandTotal = createLabel(270, 540, 105, 25,"$0.00"); //creating a label for the grand total
        }
        //METHOD FOR CREATING BUTTONS
        public JButton createButton(int y, String message) {
                JButton btn = new JButton(message);
                btn.setBounds(430,y,120,35); //setting bounds
                btn.addActionListener(this);
                return btn;
        }
        
        //METHOD TO ADD ALL COMPONENTS to the panel in the main class
        public void addComponents(JPanel p) {
                //calling the add components method in the CPT Options class
                super.addComponents(p);
                //the remaining buttons and labels are added to the panel here
                p.add(btnCalculate);
                p.add(btnClear);
                p.add(btnCheckout);
                p.add(btnExit);
                p.add(lblSubtotal);
                p.add(lblDelivery);
                p.add(lblHST);
                p.add(lblGrandTotal);
        }
        
        //METHOD FOR THE ACTIONS PERFORMED
        public void actionPerformed(ActionEvent e) {
                double subtotal, deliveryFee, HST;
                int option;
                ImageIcon littleCaesarLogo = new ImageIcon("LittleCaesarsIcon.png"); //image to show upon checkout
                if(e.getSource() instanceof JButton) { //if the source is a button, THEN check if statements for what specific button
                        //i used this here because if it is not a button, it is unneccessary to check which button because all will be false
                        //it goes to the else statement, which calls the actionPerfomed method in the CPTOptions class, passing e as a parameter
                        if(e.getSource()==btnCalculate) { //if the calculate button was clicked
                                subtotal = costToppings + costBeverages + costSize; //the subtotal is the cost of the topping and beverages and size
                                lblSubtotal.setText(nf.format(subtotal)); //set the subtotal label text
                                HST = subtotal * 0.13; //HST is 13% of subtotal
                                HST = Math.round(HST*100)/100.0; //rounding
                                lblHST.setText(nf.format(HST)); //setting HST label text
                                if(subtotal > 15) { //if the subtotal is greater than 15, it is eligibile for free delivery
                                        deliveryFee = 0; //free delivery
                                        lblDelivery.setBackground(Color.green); //green background
                                        lblDelivery.setText("FREE"); //text setting
                                }
                                else { //if it is not eligible for free delivery
                                        deliveryFee = 3; //default delivery fee
                                        lblDelivery.setText(nf.format(deliveryFee)); //text setting
                                }
                                grandTotal = subtotal + HST + deliveryFee; //grand total is the sum of all these, subtotal HST and delivery fee
                                
                                if(txtDiscount.getText().equals("ICS4U1")) {
                                        //if the user enters the correct discount code, its 20% off
                                        //It still gets free delivery if the subtotal was greater than 15
                                        grandTotal = grandTotal * 0.8;
                                        JOptionPane.showMessageDialog(null, "20% off discount applied!\nNote: Discounts are not stackable", "Discount!",JOptionPane.PLAIN_MESSAGE,new ImageIcon("discount.png"));
                                }
                                else if(txtDiscount.getText().equals("BIGSALE")) {
                                        grandTotal = grandTotal * 0.5; //the big sale is 50% off
                                        JOptionPane.showMessageDialog(null, "50% off discount applied!\nNote: Discounts are not stackable", "Discount!",JOptionPane.PLAIN_MESSAGE,new ImageIcon("discount.png"));
                                }
                                lblGrandTotal.setText(nf.format(grandTotal)); //text setting
                        }
                        else if(e.getSource()==btnClear) { //if the clear button was clicked
                                //RESETTING ALL LABELS
                                lblDelivery.setText(nf.format(0));
                                lblDelivery.setBackground(Color.white); //resetting background as it may remain gree
                                lblSubtotal.setText(nf.format(0));
                                lblHST.setText(nf.format(0));
                                lblGrandTotal.setText(nf.format(0));
                                lblSizeCost.setText(nf.format(0));
                                lblToppingsCost.setText(nf.format(0));
                                lblBeveragesCost.setText(nf.format(0));
                                for(int k = 0; k < lblImageToppings.length; k++) {
                                        lblImageToppings[k].setVisible(false); //setting all the image toppings to false
                                }
                                lblPizzaSize.setIcon(null); //removing image of pizza size
                                //RESETTING CHECK BOXES
                                for(int i = 0; i < chkToppings.length;i++) { //for loop to set all the checkboxes to false, meaning unselected
                                        chkToppings[i].setSelected(false);
                                }
                                //RESETTING RADIO BUTTONS
                                size.clearSelection(); //resetting all the radio buttons via the buttongroup
                                //RESETTING COMBO BOXES
                                for(int q = 0; q < cbBeverages.length; q++) {
                                        cbBeverages[q].setSelectedIndex(0);
                                }
                        }
                        else if(e.getSource()==btnCheckout) { //if checkout button was selected
                                if(size.getSelection()==null) { //if the size was not selected, must give error message and return to main menu
                                        JOptionPane.showMessageDialog(null, "Your order could not be completed!\nPlease select a pizza size.","Critical Error!",JOptionPane.ERROR_MESSAGE);
                                }
                                else { //if size was selected
                                        //confirming order
                                        option = JOptionPane.showConfirmDialog(null, "Is this order correct?","Little Caesar's",JOptionPane.YES_NO_OPTION);
                                        if(option==0) { //if yes, then shows message and exits
                                                JOptionPane.showMessageDialog(null, "Your order for "+nf.format(grandTotal)+" has been placed.\nThank you for ordering from Little Caesar's!\nYour Pizza will be delivered in 30 minutes or it's free!","Little Caesar's",JOptionPane.PLAIN_MESSAGE,littleCaesarLogo);
                                                System.exit(0);
                                        }
                                        //if no, nothing happens and returns to main menu
                                }
                        }
                        else { //if exit button was selected
                                //confirming decision
                                option = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?","Little Caesar's",JOptionPane.YES_NO_OPTION);
                                if(option==0) { //if yes, gives message and exits
                                        JOptionPane.showMessageDialog(null, "Thank you for choosing Little Caesars!","Little Caesar's",JOptionPane.INFORMATION_MESSAGE);
                                        System.exit(0);
                                }
                                //if no, nothing happens and returns to main menu
                        }
                }
                else { //if it was not a button that was selected through the action event, then it must be something that is within the...
                        //... actionPerformed method in the other class, which is why it is called here.
                        super.actionPerformed(e);
                }
        }
}
